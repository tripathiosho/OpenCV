### Binary Search Exercise
1. When I try to find number 5 in below list using binary search, it doesn't work and returns me -1 index. Why is that?

    ```numbers = [1,4,6,9,10,5,7]```
    
1. Find index of all the occurances of a number from sorted list

    ```
    numbers = [1,4,6,9,11,15,15,15,17,21,34,34,56]
    number_to_find = 15  
    ```
   This should return 5,6,7 as indices containing number 15 in the array
    
[Solution](https://github.com/codebasics/data-structures-algorithms-python/blob/master/algorithms/1_BinarySearch/binary_search_exercise_solution.py)    