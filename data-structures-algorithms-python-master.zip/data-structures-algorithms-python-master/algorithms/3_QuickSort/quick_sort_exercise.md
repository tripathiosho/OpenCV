### Exercise: Quick Sort
Implement quick sort using lumoto partition scheme. This partition scheme is explained in the video tutorial, you need to write python code to implement it.
Check the pseudo code here: https://en.wikipedia.org/wiki/Quicksort Check the section Lomuto partition scheme
 
 [Solution](https://github.com/codebasics/data-structures-algorithms-python/blob/master/algorithms/3_QuickSort/quick_sort_exercise_soluiton_lomuto.py)


 